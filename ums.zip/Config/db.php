<?php 

// database connection settings
return [
	'hostname' => 'localhost',
	'username' => 'root',
	'password' => '',
	'database' => 'ums',
];
